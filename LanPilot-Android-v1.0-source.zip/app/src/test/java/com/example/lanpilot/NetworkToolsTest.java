package com.example.lanpilot;

import org.junit.Test;
import java.util.List;
import static org.junit.Assert.*;

public class NetworkToolsTest {
    @Test public void validatesOnlyPrivateIpv4() {
        assertTrue(NetworkTools.isPrivateIpv4("192.168.0.57"));
        assertTrue(NetworkTools.isPrivateIpv4("10.12.14.1"));
        assertTrue(NetworkTools.isPrivateIpv4("172.31.255.2"));
        assertFalse(NetworkTools.isPrivateIpv4("8.8.8.8"));
        assertFalse(NetworkTools.isPrivateIpv4("172.32.0.1"));
        assertFalse(NetworkTools.isPrivateIpv4("192.168.0.300"));
        assertFalse(NetworkTools.isPrivateIpv4("192.168.0.1.example.com"));
        assertFalse(NetworkTools.isPrivateIpv4("127.0.0.1"));
    }
    @Test public void clampsBigSubnetsToOwnSlash24() {
        List<String> hosts = NetworkTools.boundedSubnet("192.168.0.57", 16);
        assertEquals(253, hosts.size());
        assertTrue(hosts.contains("192.168.0.32"));
        assertFalse(hosts.contains("192.168.0.57"));
        assertFalse(hosts.contains("192.168.1.1"));
    }
    @Test public void honorsSmallSubnets() {
        List<String> hosts = NetworkTools.boundedSubnet("192.168.0.57", 26);
        assertEquals(61, hosts.size());
        assertFalse(hosts.contains("192.168.0.64"));
        assertTrue(NetworkTools.boundedSubnet("192.168.0.57", 32).isEmpty());
    }
}
