package com.example.lanpilot;

import android.os.Handler;
import android.os.Looper;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicInteger;

public final class SubnetScanner {
    public interface Listener {
        void onFound(String ip, int port);
        void onProgress(int completed, int total);
        void onComplete(boolean cancelled);
    }
    private final Handler ui = new Handler(Looper.getMainLooper());
    private final AtomicBoolean cancelled = new AtomicBoolean(false);
    private ExecutorService pool;
    private boolean running = false;

    public synchronized boolean isRunning() { return running; }
    public synchronized void cancel() { cancelled.set(true); if (pool != null) pool.shutdownNow(); }

    public synchronized boolean start(List<String> targets, Listener callback) {
        if (running) return false;
        cancelled.set(false);
        running = true;
        final int total = targets.size();
        final AtomicInteger completed = new AtomicInteger(0);
        // Bound TCP pressure to at most 8 concurrent addresses; no ICMP broadcast.
        pool = Executors.newFixedThreadPool(8);
        if (total == 0) {
            running = false; ui.post(() -> callback.onComplete(false)); return true;
        }
        for (String ip : targets) {
            pool.execute(() -> {
                if (!cancelled.get() && !Thread.currentThread().isInterrupted()) {
                    int port = NetworkTools.openTcpPort(ip, new int[]{80, 443, 8008}, 180);
                    if (port > 0 && !cancelled.get()) ui.post(() -> callback.onFound(ip, port));
                }
                int n = completed.incrementAndGet();
                if (n == total || n % 12 == 0) ui.post(() -> callback.onProgress(n, total));
            });
        }
        pool.shutdown();
        Thread watcher = new Thread(() -> {
            try { pool.awaitTermination(90, TimeUnit.SECONDS); }
            catch (InterruptedException e) { Thread.currentThread().interrupt(); }
            finally {
                synchronized (SubnetScanner.this) { running = false; }
                ui.post(() -> callback.onComplete(cancelled.get()));
            }
        }, "LanPilot-scan-watcher");
        watcher.setDaemon(true);
        watcher.start();
        return true;
    }
}
