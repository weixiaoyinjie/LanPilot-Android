package com.example.lanpilot;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public final class MainActivity extends Activity {
    private static final int BG = Color.rgb(14, 23, 38);
    private static final int CARD = Color.rgb(24, 39, 57);
    private static final int CARD_DARK = Color.rgb(19, 32, 47);
    private static final int TEAL = Color.rgb(38, 212, 193);
    private static final int WHITE = Color.rgb(241, 249, 253);
    private static final int SECONDARY = Color.rgb(155, 177, 196);
    private static final int RED = Color.rgb(252, 131, 133);
    private static final int PERMISSION_LAN = 71;
    private static final int EXPORT_BACKUP = 72;
    private static final int IMPORT_BACKUP = 73;
    private static final String LAN_PERMISSION = "android.permission.ACCESS_LOCAL_NETWORK";

    private DeviceStore store;
    private SubnetScanner scanner;
    private MdnsDiscovery mdns;
    private final Handler ui = new Handler(Looper.getMainLooper());
    private final ExecutorService io = Executors.newFixedThreadPool(3);
    private LinearLayout root;
    private TextView statusView;
    private String activityMessage = "准备就绪：主动扫描，不进行后台持续检测";
    private long lastSubnetScan = 0L;
    private Runnable pendingPermissionAction;
    private boolean destroyed;

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(BG);
        getWindow().setNavigationBarColor(BG);
        store = new DeviceStore(this);
        scanner = new SubnetScanner();
        mdns = new MdnsDiscovery(this);
        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        scroll.setBackgroundColor(BG);
        root = vertical();
        root.setPadding(dp(17), dp(24), dp(17), dp(38));
        scroll.addView(root);
        setContentView(scroll);
        render();
    }
    private boolean allowed(Runnable action) {
        if (Build.VERSION.SDK_INT >= 37 && checkSelfPermission(LAN_PERMISSION) != PackageManager.PERMISSION_GRANTED) {
            pendingPermissionAction = action;
            new AlertDialog.Builder(this)
                .setTitle("允许访问局域网设备")
                .setMessage("Android 17 需要‘本地网络’权限才能扫描设备与发送插座指令。App 不上传扫描数据。")
                .setNegativeButton("取消", (dialog, which) -> pendingPermissionAction = null)
                .setPositiveButton("继续", (dialog, which) -> requestPermissions(new String[]{LAN_PERMISSION}, PERMISSION_LAN))
                .show();
            return false;
        }
        return true;
    }
    @Override public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] results) {
        super.onRequestPermissionsResult(requestCode, permissions, results);
        if (requestCode == PERMISSION_LAN) {
            Runnable action = pendingPermissionAction; pendingPermissionAction = null;
            if (results.length > 0 && results[0] == PackageManager.PERMISSION_GRANTED) {
                if (action != null) action.run();
            } else toast("没有局域网权限，无法连接本地设备。可到系统设置中开启。");
        }
    }
    private void render() {
        if (destroyed || isFinishing()) return;
        root.removeAllViews();
        LinearLayout h = vertical();
        h.addView(text("LAN  PILOT", 13, TEAL, true));
        h.addView(text("智能 Wi-Fi 设备管家", 25, WHITE, true));
        TextView sub = text("局域网设备 · IP 跟踪 · 智能插座", 12, SECONDARY, false);
        sub.setPadding(0, dp(4), 0, 0); h.addView(sub);
        root.addView(h);
        gap(root, 17);

        NetworkTools.Info net = NetworkTools.inspect(this);
        LinearLayout netBox = panel(CARD);
        netBox.addView(text("当前连接网络", 13, SECONDARY, true));
        gap(netBox, 8);
        netBox.addView(text(net.ready() ? "● 已连接 " + net.transport : "● 未检测到可用局域网", 17, net.ready()?TEAL:RED, true));
        gap(netBox, 4);
        netBox.addView(text(NetworkTools.display(net), 12, WHITE, false));
        gap(netBox, 7);
        netBox.addView(text("仅扫描当前手机连接的 IPv4 网段；无线回程隔离的设备可能无法发现。", 11, SECONDARY, false));
        root.addView(netBox);
        gap(root, 12);

        LinearLayout control = panel(CARD_DARK);
        control.addView(text("扫描与管理", 14, WHITE, true));
        gap(control, 10);
        LinearLayout line1 = horizontal();
        line1.addView(button("发现服务", true, v -> startMdns()), weight());
        gapHorizontal(line1, 8);
        line1.addView(button("轻量 IP 扫描", false, v -> startSubnet()), weight());
        control.addView(line1);
        gap(control, 9);
        LinearLayout line2 = horizontal();
        line2.addView(button("＋ 添加设备", false, v -> showEdit(new Device()), weight()));
        gapHorizontal(line2, 8);
        line2.addView(button("扫描日志", false, v -> showLogs(), weight()));
        control.addView(line2);
        if (scanner.isRunning() || mdns.isRunning()) {
            gap(control, 9);
            control.addView(button("停止当前扫描", false, v -> { scanner.cancel(); mdns.stop(); status("已请求停止扫描"); }, full()));
        }
        gap(control, 8);
        statusView = text(activityMessage, 11, SECONDARY, false);
        control.addView(statusView);
        root.addView(control);
        gap(root, 18);

        List<Device> devices = store.all();
        TextView headline = text("我的设备  ·  " + devices.size(), 17, WHITE, true);
        root.addView(headline);
        gap(root, 8);
        if (devices.isEmpty()) {
            LinearLayout empty = panel(CARD);
            empty.addView(text("还没有设备", 16, WHITE, true));
            gap(empty, 6);
            empty.addView(text("先点“发现服务”。对于没有开放 mDNS 的智能插座，可手动添加 IP 和 HTTP 命令。", 12, SECONDARY, false));
            root.addView(empty);
        } else {
            int count=0;
            for (Device d : devices) {
                if (count++ >= 100) { root.addView(text("设备超过 100 台，暂只显示前 100 台。", 12, SECONDARY, false)); break; }
                root.addView(deviceCard(d)); gap(root, 9);
            }
        }
        gap(root, 12);
        LinearLayout tools = panel(CARD_DARK);
        tools.addView(text("本地资料", 14, WHITE, true));
        gap(tools, 9);
        LinearLayout line = horizontal();
        line.addView(button("导出备份", false, v -> exportBackup(), weight()));
        gapHorizontal(line, 8);
        line.addView(button("导入备份", false, v -> importBackup(), weight()));
        tools.addView(line);
        gap(tools, 9);
        tools.addView(text("所有设备与记录保存在本机。不会自动上传、云同步或持续后台扫描。", 11, SECONDARY, false));
        root.addView(tools);
        gap(root, 13);
        root.addView(text("LAN Pilot 1.0  •  本地优先  •  探测不代表设备身份验证", 10, SECONDARY, false));
    }
    private View deviceCard(Device d) {
        LinearLayout box = panel(CARD);
        LinearLayout heading = horizontal();
        LinearLayout summary = vertical();
        summary.addView(text((d.favorite ? "★  " : "") + d.name, 16, WHITE, true));
        gap(summary, 3);
        summary.addView(text(d.kind + "  ·  " + d.ip + ":" + d.port, 12, SECONDARY, false));
        heading.addView(summary, weight());
        heading.addView(button("编辑", false, v -> showEdit(d), new LinearLayout.LayoutParams(dp(72), dp(37))));
        box.addView(heading);
        gap(box, 9);
        String state = d.status;
        String when = d.lastSeen == 0 ? "未发现过" : "最近发现 " + new SimpleDateFormat("MM-dd HH:mm", Locale.getDefault()).format(new Date(d.lastSeen));
        box.addView(text("● " + state + "     " + when, 11, "TCP端口可达".equals(state) || "服务已发现".equals(state)? TEAL:SECONDARY, false));
        if (d.boundToService()) {
            gap(box, 4);
            box.addView(text("服务身份: " + d.serviceName + " / " + d.serviceType, 11, SECONDARY, false));
        }
        gap(box, 9);
        LinearLayout row = horizontal();
        row.addView(button("检测", false, v -> checkDevice(d.id), weight()));
        gapHorizontal(row, 7);
        row.addView(button("绑定服务", false, v -> bindService(d.id), weight()));
        box.addView(row);
        if (!d.onCommand.trim().isEmpty() || !d.offCommand.trim().isEmpty()) {
            gap(box, 8);
            LinearLayout switches = horizontal();
            switches.addView(button("开启", true, v -> sendCommand(d.id, true), weight()));
            gapHorizontal(switches, 7);
            switches.addView(button("关闭", false, v -> sendCommand(d.id, false), weight()));
            box.addView(switches);
        }
        return box;
    }
    private void startMdns() {
        if (!allowed(this::startMdns)) return;
        if (scanner.isRunning() || mdns.isRunning()) { toast("请先结束正在运行的扫描"); return; }
        NetworkTools.Info info = NetworkTools.inspect(this);
        if (!info.ready()) { toast("请先连接家庭 Wi-Fi"); return; }
        mdns.start(new MdnsDiscovery.Listener() {
            @Override public void onService(String name, String type, String ip, int port) {
                if (destroyed) return;
                String change = store.foundService(name, type, ip, port);
                if (!change.isEmpty()) toast("mDNS 服务 IP 更新: " + change);
                status("发现服务 " + name + " · " + ip);
            }
            @Override public void onState(String message) { status(message); }
            @Override public void onFinished() { status("mDNS 发现结束；部分设备不公开发现服务，可改用手动添加"); render(); }
        });
        render();
    }
    private void startSubnet() {
        if (!allowed(this::startSubnet)) return;
        if (scanner.isRunning() || mdns.isRunning()) { toast("请先结束正在运行的扫描"); return; }
        NetworkTools.Info info = NetworkTools.inspect(this);
        if (!NetworkTools.isPrivateIpv4(info.ip)) { toast("需要连接私有 IPv4 家庭网络"); return; }
        if (System.currentTimeMillis()-lastSubnetScan < 45000) {
            toast("为保护 Deco 网络，请至少间隔 45 秒再扫描"); return;
        }
        List<String> targets = NetworkTools.boundedSubnet(info.ip, info.prefix);
        lastSubnetScan = System.currentTimeMillis();
        boolean started = scanner.start(targets, new SubnetScanner.Listener() {
            @Override public void onFound(String ip, int port) {
                if (destroyed) return;
                boolean added = store.foundIp(ip, port);
                if (added) store.addEvent("IP 扫描发现新开放端口 " + ip + ":" + port);
                render();
            }
            @Override public void onProgress(int done, int total) { status("轻量扫描："+done+" / "+total+" 个地址"); }
            @Override public void onComplete(boolean cancelled) { status(cancelled ? "IP 扫描已停止" : "IP 扫描结束（只识别开放 TCP 端口的设备）"); render(); }
        });
        if (started) { status("正在扫描当前 /24 内最多 254 个地址，最多 8 路并发"); render(); }
    }
    private void checkDevice(String id) {
        if (!allowed(() -> checkDevice(id))) return;
        Device d = store.find(id);
        if (d == null || !NetworkTools.isPrivateIpv4(d.ip)) { toast("IP 地址无效"); return; }
        status("正在检测 " + d.name);
        io.execute(() -> {
            int port = NetworkTools.openTcpPort(d.ip, new int[]{d.port}, 1200);
            ui.post(() -> {
                if (destroyed || store.find(id)==null) return;
                d.status = port>0 ? "TCP端口可达" : "端口未响应（不等于离线）";
                if (port>0) d.lastSeen = System.currentTimeMillis();
                store.save(d);
                status(d.name + "：" + d.status);
            });
        });
    }
    private void sendCommand(String id, boolean turnOn) {
        if (!allowed(() -> sendCommand(id, turnOn))) return;
        Device d = store.find(id);
        if (d == null) return;
        String command = turnOn ? d.onCommand : d.offCommand;
        if (command.trim().isEmpty()) { toast("请先在编辑中设置"+(turnOn?"开启":"关闭")+"命令"); return; }
        new AlertDialog.Builder(this)
            .setTitle(turnOn ? "向设备发送开启指令？" : "向设备发送关闭指令？")
            .setMessage(d.name + "  ·  " + d.ip + "\n仅在自己的局域网及授权设备上操作。")
            .setNegativeButton("取消", null)
            .setPositiveButton("发送", (dialog, which) -> {
                status("正在发送指令至 " + d.name);
                io.execute(() -> {
                    HttpSwitch.Result result = HttpSwitch.execute(d.ip, command);
                    ui.post(() -> {
                        if (destroyed) return;
                        String msg = d.name + (turnOn ? " 开启：" : " 关闭：") + result.message;
                        store.addEvent(msg);
                        status(msg); toast(result.message);
                    });
                });
            }).show();
    }
    private void bindService(String deviceId) {
        Device dest = store.find(deviceId);
        if (dest == null) return;
        List<Device> options = new ArrayList<>();
        for (Device d : store.all()) if (d.boundToService() && !d.id.equals(dest.id)) options.add(d);
        if (options.isEmpty()) {
            new AlertDialog.Builder(this).setTitle("没有可绑定的发现服务")
                .setMessage("先点击“发现服务”。只有设备广播了 mDNS 身份，才能通过服务名称跟踪 IP 更新。普通 TCP 扫描不足以验证设备身份。")
                .setPositiveButton("知道了", null).show();
            return;
        }
        String[] titles = new String[options.size()];
        for (int i=0;i<options.size();i++) titles[i]=options.get(i).name+" · "+options.get(i).ip+" · "+options.get(i).serviceType;
        new AlertDialog.Builder(this).setTitle("绑定到已有设备："+dest.name)
            .setItems(titles, (dialog, index) -> {
                Device service=options.get(index);
                new AlertDialog.Builder(this).setTitle("确认设备身份")
                    .setMessage("请通过设备管理页面或实物确认这是同一台设备。\n\n"+dest.name+"（"+dest.ip+"）\n↔ " + service.name+"（"+service.ip+"）\n\n绑定后将自动更新 IP，并保留原来的开关命令。")
                    .setNegativeButton("取消", null)
                    .setPositiveButton("确认绑定", (dlg, which) -> {
                        String previous=dest.ip;
                        dest.serviceName=service.serviceName;
                        dest.serviceType=service.serviceType;
                        dest.ip=service.ip; dest.port=service.port;
                        dest.lastSeen=System.currentTimeMillis();
                        dest.status="服务已绑定";
                        store.save(dest);
                        store.remove(service.id);
                        store.addEvent(dest.name + " 绑定服务，IP " + previous + " → " + dest.ip);
                        status("绑定完成；下次 mDNS 发现同一服务时可更新 IP");
                    }).show();
            }).setNegativeButton("取消", null).show();
    }
    private void showEdit(Device original) {
        Device draft;
        try { draft = Device.fromJson(original.json()); } catch (Exception ex) { draft = new Device(); }
        final Device d = draft;
        ScrollView scroll = new ScrollView(this);
        LinearLayout contents=vertical(); contents.setPadding(dp(20), dp(8), dp(20), dp(6));
        scroll.addView(contents);
        EditText name=editField(contents,"设备名称",d.name);
        EditText ip=editField(contents,"设备 IP（仅支持私有 IPv4）",d.ip);
        EditText port=editField(contents,"服务端口（1–65535）",String.valueOf(d.port));
        port.setInputType(android.text.InputType.TYPE_CLASS_NUMBER);
        EditText kind=editField(contents,"设备类型，例如 插座 / 电视 / Deco",d.kind);
        EditText on=editField(contents,"开启命令（支持 GET/POST）",d.onCommand);
        EditText off=editField(contents,"关闭命令（支持 GET/POST）",d.offCommand);
        TextView tip=text("示例：GET http://{ip}/relay/0?turn=on\n关闭：GET http://{ip}/relay/0?turn=off\n\n必须替换为你的设备实际支持的接口。命令只会发送到配置的本地 IP，不跟随 HTTP 跳转；成功响应不等于已确认设备物理状态。",11,SECONDARY,false);
        tip.setPadding(0,dp(10),0,dp(5)); contents.addView(tip);
        final boolean[] favorite={d.favorite};
        Button fav=button(d.favorite ? "★ 取消置顶" : "☆ 设为常用设备",false,null,full());
        fav.setOnClickListener(v -> { favorite[0]=!favorite[0]; fav.setText(favorite[0]?"★ 取消置顶":"☆ 设为常用设备"); });
        contents.addView(fav);
        AlertDialog dialog = new AlertDialog.Builder(this).setTitle("设备设置")
            .setView(scroll).setNegativeButton("取消",null)
            .setNeutralButton("删除",null)
            .setPositiveButton("保存",null).create();
        dialog.setOnShowListener(unused -> {
            dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v -> {
                String newIp=ip.getText().toString().trim();
                String newName=name.getText().toString().trim();
                int newPort;
                try { newPort=Integer.parseInt(port.getText().toString().trim()); }
                catch (Exception ex) { toast("端口必须为数字"); return; }
                if (newName.isEmpty() || !NetworkTools.isPrivateIpv4(newIp) || newPort<1 || newPort>65535) {
                    toast("请填写设备名称、有效私有 IPv4 和正确端口"); return;
                }
                d.name=newName; d.ip=newIp; d.port=newPort;
                d.kind=kind.getText().toString().trim();
                d.onCommand=on.getText().toString().trim(); d.offCommand=off.getText().toString().trim();
                d.favorite=favorite[0];
                store.save(d); store.addEvent("保存设备 " + d.name + " · " + d.ip);
                dialog.dismiss(); render();
            });
            dialog.getButton(AlertDialog.BUTTON_NEUTRAL).setTextColor(RED);
            dialog.getButton(AlertDialog.BUTTON_NEUTRAL).setOnClickListener(v -> {
                if (store.find(d.id)==null) { dialog.dismiss(); return; }
                new AlertDialog.Builder(this).setTitle("删除设备？")
                    .setMessage("删除 " + d.name + "，不会更改设备本身的设置。")
                    .setNegativeButton("取消",null)
                    .setPositiveButton("删除",(dlg,w)->{
                        store.remove(d.id); store.addEvent("删除设备 " + d.name);
                        dialog.dismiss(); render();
                    }).show();
            });
        });
        dialog.show();
    }
    private EditText editField(LinearLayout box,String label,String value) {
        TextView t = text(label,12,SECONDARY,true); t.setPadding(0,dp(8),0,dp(4)); box.addView(t);
        EditText edit = new EditText(this);
        edit.setText(value); edit.setSingleLine(true); edit.setTextSize(14); edit.setTextColor(WHITE);
        edit.setHintTextColor(SECONDARY); edit.setSelectAllOnFocus(false);
        edit.setBackground(round(CARD, 10));
        edit.setPadding(dp(12),dp(9),dp(12),dp(9));
        box.addView(edit,new LinearLayout.LayoutParams(-1,dp(45)));
        return edit;
    }
    private void showLogs() {
        List<String> events=store.logs();
        StringBuilder builder=new StringBuilder();
        for (int i=0;i<Math.min(80,events.size());i++) builder.append(events.get(i)).append("\n\n");
        new AlertDialog.Builder(this).setTitle("本机操作记录")
            .setMessage(builder.length()==0 ? "暂时没有记录" : builder.toString())
            .setNegativeButton("关闭",null)
            .setPositiveButton("分享文本",(dialog,which) -> {
                Intent share=new Intent(Intent.ACTION_SEND);
                share.setType("text/plain"); share.putExtra(Intent.EXTRA_TEXT,builder.toString());
                startActivity(Intent.createChooser(share,"分享日志"));
            }).show();
    }
    private void exportBackup() {
        Intent intent=new Intent(Intent.ACTION_CREATE_DOCUMENT);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.setType("application/json");
        intent.putExtra(Intent.EXTRA_TITLE,"LanPilot-backup.json");
        startActivityForResult(intent,EXPORT_BACKUP);
    }
    private void importBackup() {
        Intent intent=new Intent(Intent.ACTION_OPEN_DOCUMENT);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.setType("*/*");
        startActivityForResult(intent,IMPORT_BACKUP);
    }
    @Override @SuppressWarnings("deprecation") protected void onActivityResult(int req,int result,Intent data) {
        super.onActivityResult(req,result,data);
        if (result != RESULT_OK || data==null || data.getData()==null) return;
        try {
            if (req==EXPORT_BACKUP) {
                try (OutputStream out=getContentResolver().openOutputStream(data.getData())) {
                    if (out==null) throw new IllegalStateException("无法打开输出文件");
                    out.write(store.exportJson().getBytes(StandardCharsets.UTF_8));
                }
                toast("备份导出成功");
            } else if (req==IMPORT_BACKUP) {
                ByteArrayOutputStream dataBytes = new ByteArrayOutputStream();
                try (InputStream input=getContentResolver().openInputStream(data.getData())) {
                    if (input==null) throw new IllegalStateException("无法读取文件");
                    byte[] buffer=new byte[4096]; int n;
                    while ((n=input.read(buffer))!=-1) {
                        dataBytes.write(buffer,0,n);
                        if (dataBytes.size()>1024*1024) throw new IllegalStateException("文件超出 1MB 限制");
                    }
                }
                String json = dataBytes.toString("UTF-8");
                new AlertDialog.Builder(this).setTitle("导入设备备份？")
                    .setMessage("将按设备 ID 合并本机配置。同 ID 的设备设置会被备份覆盖。")
                    .setNegativeButton("取消",null)
                    .setPositiveButton("确认",(dialog,which)->{
                        try { int count=store.importJson(json); toast("已导入 " + count + " 台设备"); render(); }
                        catch (Exception e) { toast("导入失败："+e.getMessage()); }
                    }).show();
            }
        } catch (Exception e) { toast("文件操作失败："+e.getMessage()); }
    }
    private void status(String message) {
        activityMessage=message;
        if (!destroyed && statusView != null) statusView.setText(message);
    }
    private void toast(String text) { Toast.makeText(this,text,Toast.LENGTH_LONG).show(); }
    @Override protected void onStop() {
        super.onStop();
        if (scanner!=null) scanner.cancel();
        if (mdns!=null) mdns.stop();
    }
    @Override protected void onDestroy() {
        destroyed=true;
        if (scanner!=null) scanner.cancel();
        if (mdns!=null) mdns.stop();
        io.shutdownNow();
        super.onDestroy();
    }

    private int dp(float value) { return (int)(value*getResources().getDisplayMetrics().density+0.5f); }
    private LinearLayout vertical() { LinearLayout b=new LinearLayout(this); b.setOrientation(LinearLayout.VERTICAL); return b; }
    private LinearLayout horizontal() { LinearLayout b=new LinearLayout(this); b.setOrientation(LinearLayout.HORIZONTAL); b.setGravity(Gravity.CENTER_VERTICAL); return b; }
    private LinearLayout.LayoutParams weight() { return new LinearLayout.LayoutParams(0,-2,1f); }
    private LinearLayout.LayoutParams full() { return new LinearLayout.LayoutParams(-1,-2); }
    private void gap(LinearLayout into,int h) { View v=new View(this); into.addView(v,new LinearLayout.LayoutParams(1,dp(h))); }
    private void gapHorizontal(LinearLayout into,int w) { View v=new View(this); into.addView(v,new LinearLayout.LayoutParams(dp(w),1)); }
    private TextView text(String label,int size,int color,boolean bold) {
        TextView t=new TextView(this); t.setText(label); t.setTextSize(size); t.setTextColor(color);
        if (bold) t.setTypeface(Typeface.DEFAULT,Typeface.BOLD);
        return t;
    }
    private GradientDrawable round(int color,int radius) {
        GradientDrawable d=new GradientDrawable(); d.setColor(color); d.setCornerRadius(dp(radius)); return d;
    }
    private LinearLayout panel(int color) {
        LinearLayout panel=vertical(); panel.setPadding(dp(14),dp(14),dp(14),dp(14));
        panel.setBackground(round(color,16)); return panel;
    }
    private Button button(String label,boolean primary,View.OnClickListener action,LinearLayout.LayoutParams size) {
        Button b=new Button(this); b.setText(label); b.setTextSize(12); b.setAllCaps(false);
        b.setTextColor(primary?BG:WHITE); b.setTypeface(Typeface.DEFAULT,Typeface.BOLD);
        b.setMinHeight(0); b.setMinimumHeight(0); b.setPadding(dp(7),dp(7),dp(7),dp(7));
        b.setBackground(round(primary?TEAL:Color.rgb(45,64,83),11));
        if (action != null) b.setOnClickListener(action);
        size.height=dp(40); b.setLayoutParams(size);
        return b;
    }
}
