package com.example.lanpilot;

import android.content.Context;
import android.net.ConnectivityManager;
import android.net.LinkAddress;
import android.net.LinkProperties;
import android.net.Network;
import android.net.NetworkCapabilities;
import android.net.RouteInfo;
import java.net.Inet4Address;
import java.net.InetAddress;
import java.net.Socket;
import java.net.InetSocketAddress;
import java.util.ArrayList;
import java.util.List;

public final class NetworkTools {
    private NetworkTools() { }
    public static final class Info {
        public String ip = "";
        public String gateway = "";
        public int prefix = 24;
        public String transport = "未连接";
        public boolean ready() { return !ip.isEmpty(); }
    }
    public static Info inspect(Context ctx) {
        Info info = new Info();
        ConnectivityManager cm = (ConnectivityManager) ctx.getSystemService(Context.CONNECTIVITY_SERVICE);
        if (cm == null) return info;
        Network selected = null;
        // Prefer real Wi-Fi to default VPN interface.
        for (Network network : cm.getAllNetworks()) {
            NetworkCapabilities caps = cm.getNetworkCapabilities(network);
            if (caps != null && caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI)) { selected = network; info.transport = "Wi-Fi"; break; }
        }
        if (selected == null) {
            for (Network network : cm.getAllNetworks()) {
                NetworkCapabilities caps = cm.getNetworkCapabilities(network);
                if (caps != null && caps.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET)) { selected=network; info.transport="有线网络"; break; }
            }
        }
        if (selected == null) return info;
        LinkProperties lp = cm.getLinkProperties(selected);
        if (lp == null) return info;
        for (LinkAddress a : lp.getLinkAddresses()) if (a.getAddress() instanceof Inet4Address) {
            info.ip = a.getAddress().getHostAddress(); info.prefix = a.getPrefixLength(); break;
        }
        for (RouteInfo r : lp.getRoutes()) if (r.isDefaultRoute() && r.hasGateway() && r.getGateway() instanceof Inet4Address) {
            info.gateway = r.getGateway().getHostAddress(); break;
        }
        return info;
    }
    public static boolean isPrivateIpv4(String ip) {
        String[] parts = ip == null ? new String[0] : ip.split("\\.", -1);
        if (parts.length != 4) return false;
        int[] n = new int[4];
        for (int i=0;i<4;i++) {
            if (parts[i].isEmpty() || parts[i].length()>3 || !parts[i].matches("[0-9]+")) return false;
            try { n[i] = Integer.parseInt(parts[i]); } catch (Exception ex) { return false; }
            if (n[i]>255) return false;
        }
        return n[0]==10 || (n[0]==172 && n[1]>=16 && n[1]<=31)
                || (n[0]==192 && n[1]==168);
    }
    public static List<String> boundedSubnet(String ip, int prefix) {
        List<String> out = new ArrayList<>();
        if (!isPrivateIpv4(ip)) return out;
        String[] p = ip.split("\\.");
        // Never enumerate more than the local /24. Honor smaller networks (/25-/30).
        int last = Integer.parseInt(p[3]);
        if (prefix > 30) return out;
        int bits = Math.max(24, prefix);
        int size = 1 << (32 - bits);
        int start = (last / size) * size;
        int end = start + size - 1;
        String head = p[0] + "." + p[1] + "." + p[2] + ".";
        for (int i=start+1;i<end;i++) if (i != last) out.add(head+i);
        return out;
    }
    public static int openTcpPort(String ip, int[] ports, int timeoutMs) {
        for (int port : ports) {
            try (Socket socket = new Socket()) {
                socket.connect(new InetSocketAddress(ip, port), timeoutMs);
                return port;
            } catch (Exception ignored) { }
        }
        return -1;
    }
    public static String display(Info i) {
        return i.ready() ? (i.transport+" · "+i.ip+"/"+i.prefix+" · 网关 "+(i.gateway.isEmpty()?"未知":i.gateway)) : "未识别到 Wi-Fi / 有线 IPv4 网络";
    }
}
