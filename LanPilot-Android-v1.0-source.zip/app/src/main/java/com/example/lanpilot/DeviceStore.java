package com.example.lanpilot;

import android.content.Context;
import android.content.SharedPreferences;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

public final class DeviceStore {
    private final SharedPreferences prefs;
    private final List<Device> devices = new ArrayList<>();
    private final List<String> history = new ArrayList<>();
    public DeviceStore(Context context) {
        prefs = context.getSharedPreferences("lanpilot_local_v1", Context.MODE_PRIVATE);
        try {
            JSONArray arr = new JSONArray(prefs.getString("devices", "[]"));
            for (int i=0; i<arr.length(); i++) devices.add(Device.fromJson(arr.getJSONObject(i)));
        } catch (Exception ignored) { }
        try {
            JSONArray arr = new JSONArray(prefs.getString("events", "[]"));
            for (int i=0; i<arr.length(); i++) history.add(arr.optString(i));
        } catch (Exception ignored) { }
    }
    public synchronized List<Device> all() {
        List<Device> result = new ArrayList<>(devices);
        result.sort(Comparator.comparing((Device d) -> !d.favorite)
                .thenComparing(d -> d.name, String.CASE_INSENSITIVE_ORDER));
        return result;
    }
    public synchronized Device find(String id) {
        for (Device d : devices) if (d.id.equals(id)) return d;
        return null;
    }
    public synchronized List<String> logs() { return new ArrayList<>(history); }
    public synchronized void save(Device device) {
        for (int i=0; i<devices.size(); i++) {
            if (devices.get(i).id.equals(device.id)) {
                devices.set(i, device); flush(); return;
            }
        }
        devices.add(device); flush();
    }
    public synchronized void remove(String id) {
        devices.removeIf(d -> d.id.equals(id)); flush();
    }
    // Never infer identity from IP alone for auto-rebinding.
    // mDNS service name AND service type are required for a safe automatic match.
    public synchronized String foundService(String name, String type, String ip, int port) {
        if (name.isEmpty() || type.isEmpty() || ip.isEmpty()) return "";
        for (Device d : devices) {
            if (name.equals(d.serviceName) && type.equals(d.serviceType)) {
                String old = d.ip;
                d.ip = ip;
                d.port = port > 0 ? port : d.port;
                d.lastSeen = System.currentTimeMillis();
                d.status = "服务已发现";
                if (!old.isEmpty() && !old.equals(ip)) {
                    addEventNoFlush(d.name + " IP变化: " + old + " → " + ip);
                    flush(); return d.name + "：" + old + " → " + ip;
                }
                flush(); return "";
            }
        }
        // Unbound IP-only entries are not automatically claimed; two hosts can reuse an IP.
        Device d = new Device();
        d.name = name; d.ip = ip; d.port = port > 0 ? port : 80;
        d.kind = guessKind(type, name);
        d.serviceName = name; d.serviceType = type; d.discovered = true;
        d.lastSeen = System.currentTimeMillis(); d.status = "服务已发现";
        devices.add(d); flush(); return "";
    }
    public synchronized boolean foundIp(String ip, int port) {
        if (ip.isEmpty()) return false;
        for (Device d : devices) {
            if (ip.equals(d.ip)) {
                d.lastSeen = System.currentTimeMillis();
                d.status = "TCP端口可达";
                flush(); return false;
            }
        }
        Device d = new Device(); d.name = "设备 " + ip.substring(ip.lastIndexOf('.') + 1);
        d.ip = ip; d.port = port; d.kind = "待识别";
        d.discovered = true; d.lastSeen = System.currentTimeMillis();
        d.status = "TCP端口可达"; devices.add(d); flush(); return true;
    }
    public synchronized void addEvent(String msg) { addEventNoFlush(msg); flush(); }
    private void addEventNoFlush(String msg) {
        String text = new java.text.SimpleDateFormat("MM-dd HH:mm:ss", java.util.Locale.getDefault())
                .format(new java.util.Date()) + "  " + msg;
        history.add(0, text);
        while (history.size() > 120) history.remove(history.size() - 1);
    }
    private synchronized void flush() {
        JSONArray arr = new JSONArray();
        for (Device d : devices) try { arr.put(d.json()); } catch (JSONException ignored) { }
        JSONArray logs = new JSONArray(); for (String s : history) logs.put(s);
        prefs.edit().putString("devices", arr.toString()).putString("events", logs.toString()).apply();
    }
    public synchronized String exportJson() {
        JSONObject root = new JSONObject(); JSONArray arr = new JSONArray();
        for (Device d : devices) try { arr.put(d.json()); } catch (JSONException ignored) { }
        try { root.put("format", "LanPilotBackupV1"); root.put("devices", arr); }
        catch (JSONException ignored) { }
        return root.toString();
    }
    // Import preserves user-controlled records and merges only matching IDs.
    public synchronized int importJson(String raw) throws JSONException {
        JSONObject root = new JSONObject(raw);
        if (!"LanPilotBackupV1".equals(root.optString("format"))) throw new JSONException("不是LanPilot备份文件");
        JSONArray arr = root.getJSONArray("devices");
        if (arr.length() > 500) throw new JSONException("备份设备数量过多");
        int count = 0;
        for (int i=0; i<arr.length(); i++) {
            Device imported = Device.fromJson(arr.getJSONObject(i));
            if (!NetworkTools.isPrivateIpv4(imported.ip)) continue;
            Device old = find(imported.id);
            if (old != null) devices.remove(old);
            devices.add(imported); count++;
        }
        addEventNoFlush("导入配置 " + count + " 台设备");
        flush(); return count;
    }
    public static String guessKind(String type, String name) {
        String s = (type + " " + name).toLowerCase(java.util.Locale.ROOT);
        if (s.contains("googlecast") || s.contains("chromecast")) return "电视/投屏";
        if (s.contains("printer") || s.contains("ipp")) return "打印机";
        if (s.contains("shelly") || s.contains("plug") || s.contains("tasmota")) return "智能插座";
        if (s.contains("hap") || s.contains("homekit")) return "智能家居";
        return "其他";
    }
}
