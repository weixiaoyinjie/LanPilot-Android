package com.example.lanpilot;

import java.io.IOException;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URI;
import java.util.Locale;

public final class HttpSwitch {
    private HttpSwitch() { }
    public static final class Result {
        public final boolean ok;
        public final String message;
        Result(boolean success, String text) { ok=success; message=text; }
    }
    /**
     * Command examples: GET http://{ip}/relay/0?turn=on
     *                   POST http://{ip}/api/relay/on
     * The URL must resolve to EXACTLY the currently configured private LAN IP.
     * This prevents accidentally sending commands/tokens to public hosts.
     */
    public static Result execute(String ip, String command) {
        if (!NetworkTools.isPrivateIpv4(ip)) return new Result(false,"请先配置私有局域网 IPv4 地址");
        String cmd = command == null ? "" : command.trim();
        if (cmd.isEmpty()) return new Result(false,"还没有设置开关命令");
        String method = "GET";
        if (cmd.toUpperCase(Locale.ROOT).startsWith("POST ")) { method="POST"; cmd=cmd.substring(5).trim(); }
        else if (cmd.toUpperCase(Locale.ROOT).startsWith("GET ")) cmd=cmd.substring(4).trim();
        cmd = cmd.replace("{ip}", ip);
        HttpURLConnection connection = null;
        try {
            URI uri = new URI(cmd);
            if (!"http".equalsIgnoreCase(uri.getScheme()) && !"https".equalsIgnoreCase(uri.getScheme()))
                return new Result(false,"命令必须使用 http:// 或 https://");
            if (uri.getHost()==null || !uri.getHost().equals(ip) || uri.getUserInfo()!=null)
                return new Result(false,"为安全起见，URL 主机必须等于设备的局域网 IP");
            if (uri.getRawFragment()!=null) return new Result(false,"不支持带 # 的命令");
            connection = (HttpURLConnection) new URL(uri.toString()).openConnection();
            connection.setRequestMethod(method);
            connection.setConnectTimeout(3000);
            connection.setReadTimeout(3000);
            connection.setInstanceFollowRedirects(false);
            connection.setUseCaches(false);
            int status = connection.getResponseCode();
            if (status >= 200 && status < 300) return new Result(true,"收到 HTTP " + status + "，设备是否执行需实测确认");
            return new Result(false,"设备返回 HTTP " + status + "，未确认执行");
        } catch (Exception ex) {
            return new Result(false, ex.getClass().getSimpleName()+": "+ex.getMessage());
        } finally { if (connection != null) connection.disconnect(); }
    }
}
