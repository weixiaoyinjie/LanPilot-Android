package com.example.lanpilot;

import android.content.Context;
import android.net.nsd.NsdManager;
import android.net.nsd.NsdServiceInfo;
import android.net.wifi.WifiManager;
import android.os.Handler;
import android.os.Looper;
import java.net.InetAddress;

public final class MdnsDiscovery {
    public interface Listener {
        void onService(String name, String type, String ip, int port);
        void onState(String status);
        void onFinished();
    }
    private static final String[] TYPES = {"_http._tcp.", "_googlecast._tcp.", "_hap._tcp.", "_ipp._tcp."};
    private final NsdManager manager;
    private final WifiManager wifi;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private NsdManager.DiscoveryListener activeListener;
    private WifiManager.MulticastLock lock;
    private Listener callback;
    private boolean running;
    private int current;
    private int generation;
    private Runnable nextAction;

    public MdnsDiscovery(Context context) {
        manager = (NsdManager) context.getSystemService(Context.NSD_SERVICE);
        wifi = (WifiManager) context.getApplicationContext().getSystemService(Context.WIFI_SERVICE);
    }
    public boolean isRunning() { return running; }
    public void start(Listener listener) {
        if (running) return;
        running = true; current = 0; generation++; callback = listener;
        try {
            if (wifi != null) {
                lock = wifi.createMulticastLock("LanPilot-mdns-foreground");
                lock.setReferenceCounted(false); lock.acquire();
            }
        } catch (Exception ignored) { }
        discoverNext(generation);
    }
    private void discoverNext(int session) {
        if (!running || session != generation) return;
        stopActiveListener();
        if (current >= TYPES.length) { finish(); return; }
        final String type = TYPES[current++];
        callback.onState("mDNS 正在查找 " + type + " (" + current + "/" + TYPES.length + ")");
        activeListener = new NsdManager.DiscoveryListener() {
            @Override public void onDiscoveryStarted(String serviceType) { }
            @Override public void onServiceFound(NsdServiceInfo serviceInfo) {
                if (running && session == generation) resolve(serviceInfo, session);
            }
            @Override public void onServiceLost(NsdServiceInfo serviceInfo) { }
            @Override public void onDiscoveryStopped(String serviceType) { }
            @Override public void onStartDiscoveryFailed(String serviceType, int errorCode) {
                callback.onState("mDNS 类型暂不可用: " + serviceType + " (" + errorCode + ")");
                if (nextAction != null) { handler.removeCallbacks(nextAction); handler.post(nextAction); }
            }
            @Override public void onStopDiscoveryFailed(String serviceType, int errorCode) { }
        };
        // Interval limited to 5 seconds per type to avoid permanent multicast discovery.
        nextAction = () -> { nextAction = null; discoverNext(session); };
        try { manager.discoverServices(type, NsdManager.PROTOCOL_DNS_SD, activeListener); }
        catch (Exception ex) { callback.onState("mDNS 启动失败: " + ex.getMessage()); handler.post(nextAction); return; }
        handler.postDelayed(nextAction, 5000);
    }
    @SuppressWarnings("deprecation")
    private void resolve(NsdServiceInfo service, int session) {
        try {
            manager.resolveService(service, new NsdManager.ResolveListener() {
                @Override public void onResolveFailed(NsdServiceInfo info, int errorCode) { }
                @Override public void onServiceResolved(NsdServiceInfo info) {
                    if (!running || session != generation) return;
                    InetAddress address = info.getHost();
                    if (address != null && NetworkTools.isPrivateIpv4(address.getHostAddress())) {
                        handler.post(() -> {
                            if (running && session == generation)
                                callback.onService(info.getServiceName(), info.getServiceType(), address.getHostAddress(), info.getPort());
                        });
                    }
                }
            });
        } catch (Exception ignored) { }
    }
    private void stopActiveListener() {
        if (activeListener != null) {
            try { manager.stopServiceDiscovery(activeListener); } catch (Exception ignored) { }
            activeListener = null;
        }
    }
    private void finish() {
        if (!running) return;
        running = false; generation++;
        if (nextAction != null) { handler.removeCallbacks(nextAction); nextAction = null; }
        stopActiveListener();
        if (lock != null) { try { if (lock.isHeld()) lock.release(); } catch (Exception ignored) { } lock = null; }
        if (callback != null) callback.onFinished();
    }
    public void stop() { finish(); }
}
