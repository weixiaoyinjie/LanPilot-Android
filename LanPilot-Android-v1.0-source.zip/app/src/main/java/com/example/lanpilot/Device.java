package com.example.lanpilot;

import org.json.JSONException;
import org.json.JSONObject;
import java.util.UUID;

public final class Device {
    public String id = UUID.randomUUID().toString();
    public String name = "新设备";
    public String ip = "";
    public int port = 80;
    public String kind = "其他";
    public String serviceName = "";
    public String serviceType = "";
    public String onCommand = "";
    public String offCommand = "";
    public boolean favorite = false;
    public boolean discovered = false;
    public long lastSeen = 0;
    public String status = "未检测"; // only in-memory; never claim 'offline'

    public boolean boundToService() { return !serviceName.isEmpty() && !serviceType.isEmpty(); }
    public JSONObject json() throws JSONException {
        JSONObject j = new JSONObject();
        j.put("id", id); j.put("name", name); j.put("ip", ip);
        j.put("port", port); j.put("kind", kind);
        j.put("serviceName", serviceName); j.put("serviceType", serviceType);
        j.put("onCommand", onCommand); j.put("offCommand", offCommand);
        j.put("favorite", favorite); j.put("discovered", discovered);
        j.put("lastSeen", lastSeen);
        return j;
    }
    public static Device fromJson(JSONObject j) {
        Device d = new Device();
        d.id = j.optString("id", d.id);
        d.name = j.optString("name", d.name);
        d.ip = j.optString("ip", "");
        d.port = j.optInt("port", 80);
        d.kind = j.optString("kind", "其他");
        d.serviceName = j.optString("serviceName", "");
        d.serviceType = j.optString("serviceType", "");
        d.onCommand = j.optString("onCommand", "");
        d.offCommand = j.optString("offCommand", "");
        d.favorite = j.optBoolean("favorite", false);
        d.discovered = j.optBoolean("discovered", false);
        d.lastSeen = j.optLong("lastSeen", 0);
        return d;
    }
}
