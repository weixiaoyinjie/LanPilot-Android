# LAN Pilot / 智能 Wi-Fi 设备管家

原生 Android Java App，**无服务器、无云账号、无需 API Key**。扫描、设备资料和操作日志全部只保存在手机中。针对家用 Deco / Google TV / 智能插座等局域网设备。

## 已实现功能

| 功能 | 说明 |
|---|---|
| 网络概览 | 当前 Wi-Fi / 有线 IPv4、前缀与默认网关；优先识别实体 Wi-Fi，避免误扫 VPN |
| mDNS 设备发现 | 顺序查找 `_http._tcp.`、`_googlecast._tcp.`、`_hap._tcp.`、`_ipp._tcp.`，每种 5 秒，结束后释放组播锁 |
| 轻量 IP 扫描 | 仅本机当前私有网段，最多 /24；8 路并发、180 毫秒 TCP 超时、45 秒冷却；探测端口 80/443/8008 |
| 手动添加 | 名称、私有 IPv4、端口、类型、常用置顶 |
| 网络状态检测 | 指定端口是否接受 TCP 连接。未响应不能直接判定设备离线 |
| IP 变更跟踪 | **仅匹配 mDNS 服务名称+服务类型** 才自动修改地址，并记录旧/新 IP |
| 服务绑定 | 手动验证身份后，把已发现 mDNS 服务绑定到已保存的插座 |
| 自定义 HTTP 控制 | 每台设备独立设置开/关 GET / POST URL（无请求体），支持 `{ip}` 占位符、操作前确认、严格禁止 URL 指向设备 IP 以外的主机 |
| 操作历史 | 保留最近 120 条本地事件，支持分享文本 |
| 备份与恢复 | 通过 Android 文件选择器导出/导入 JSON（无自动上传） |
| Android 17 | 面向 SDK 37，声明并在运行时请求 `ACCESS_LOCAL_NETWORK` 权限 |
| 网络负载保护 | 无后台轮询、无广播 ping、不能两个扫描并行；切到后台自动停止扫描 |

## ⚠️ 重要说明

- **不能保证发现每一台设备**：mDNS 需要设备广播服务；轻量 IP 扫描只能检测到指定 TCP 端口有响应的设备。通常无法仅凭 Android 公共 API 可靠得到设备真实 MAC 地址。
- **不能仅凭 IP 识别设备**。仅 IP 的设备如果 DHCP 地址改变，需要人工确认并编辑 IP；mDNS 设备可以通过服务身份重新关联，但重名服务仍需人工核验。
- **不会修复 Deco 回程拥堵**。仅减少本 App 自身探测强度。
- Google TV 的 8008 端口是否开放取决于其系统/网络设置；发现 Google Cast 不代表可以控制全部影音 App。
- HTTP 开关接口**完全取决于插座厂商、固件及用户现有脚本**。若没有 HTTP 控制协议，App 无法直接开关。HTTP 200 仅意味着请求被服务器接受，不保证继电器动作。
- HTTP 明文传输可能暴露 URL 参数中的令牌，因此只应在受信任的 LAN 使用，**不要将设备 HTTP 接口映射到公网**。备份 JSON 包含命令 URL，注意保护。
- `POST` 目前发送无请求体，适合通过 URL 路径控制的设备；JSON 请求体、认证 Header、MQTT 不属于此版本。
- 没有进行智能插座电气负载、安全性或远程网络控制认证。

## GitHub Actions 自动编译 APK（无需本地 Android Studio）

1. GitHub 新建**空仓库**，例如 `LanPilot-Android`。不要勾选自动创建 README。
2. 解压本 ZIP；将 ZIP 内**全部文件和隐藏的 `.github` 文件夹**一起上传到仓库根目录。GitHub 网页上传可一次拖入解压后的项目文件夹内容，或者使用 Git 命令推送。
3. 打开 `Actions` → `Build Android APK` → `Run workflow`。
4. 完成后进入该次运行的 `Artifacts`，下载 `LanPilot-v1.0-debug-apk`，解压后得到 `app-debug.apk`。
5. 在 Android 手机上安装 debug APK。Android 17 第一次扫描前需允许**本地网络**权限。

项目采用 GitHub Actions 安装指定版本 Gradle，因此无需额外提供 Gradle Wrapper 二进制文件。Push 到 `main` / `master` 分支也会自动编译。编译使用 Android Gradle Plugin **9.3.0**、Gradle **9.5.1**、JDK **17**、compile/target SDK **37**。GitHub Actions 会联网下载 Android SDK 和编译依赖，但 **App 自身运行不依赖外部服务器**。

## 插座示例

1. 新增设备“插座 A”，IP `192.168.0.57`（**仅示例，不默认控制该地址**），端口 `80`。
2. 在“开启命令”填入厂商实际支持的地址，例如：`GET http://{ip}/relay/0?turn=on`。
3. 在“关闭命令”填入 `GET http://{ip}/relay/0?turn=off`。
4. 保存，先点击“检测”查看设备管理端口，再点“开启/关闭”。App 会要求再次确认。
5. 如果设备广播 mDNS，先“发现服务”，然后“绑定服务”并核验物理身份，后续才可能自动跟踪 DHCP IP 变化。

> 上述 `/relay/0?turn=on` 只是 **语法示例**，并非任何特定品牌的真实 API。应替换成你已经测试成功的脚本地址。

## 项目布局

```text
LanPilot-Android/
├── .github/workflows/build-apk.yml     # GitHub 自动生成 APK
├── app/build.gradle                    # Android 构建配置
├── app/src/main/AndroidManifest.xml    # 权限
├── app/src/main/java/com/example/lanpilot/
│   ├── MainActivity.java               # 主界面与操作
│   ├── Device.java                     # 设备模型
│   ├── DeviceStore.java                # 本地数据库、IP 身份关联、备份
│   ├── NetworkTools.java               # 网络信息和小范围 TCP 探测
│   ├── SubnetScanner.java              # 有限并发扫描
│   ├── MdnsDiscovery.java              # 局域网广播服务发现
│   └── HttpSwitch.java                 # HTTP 命令安全校验与发送
└── README.md
```

## 隐私与安全

App 未接入外部分析或广告 SDK，无固定公网请求地址。设备资料存 `SharedPreferences`，不会自动共享。网络探测和 HTTP 开关必须用户主动点击。**仅扫描有权管理的家庭网络**。

## 版本计划（未实现，不应误认现有功能）

- V1.1：独立的 Wi-Fi / Deco 可达性趋势图、网络切换日志（须用户主动启用适当前台服务）。
- V1.2：对不同智能插座固件提供适配器、POST JSON Body/Token 安全存储。
- V1.3：mDNS 持久身份补强、人工确认冲突，以及更精细的探测频率控制。

### GitHub Actions 2026-10-26 SDK 初始化兼容调整

工作流固定使用 `ubuntu-24.04` 运行器预装的 Android SDK。省略 `android-actions/setup-android@v3` 和重复的 SDK 安装步骤，降低远程仓库/许可证同步故障风险。由于预装 Android SDK 37 平台目录为 `android-37.0`，自动创建供部分 Android Gradle 插件识别的 `android-37` 符号链接。本修复尚未在实际 GitHub Actions 运行中验证。
